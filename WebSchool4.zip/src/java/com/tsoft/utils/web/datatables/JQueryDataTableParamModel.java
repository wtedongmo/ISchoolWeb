/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tsoft.utils.web.datatables;

public class JQueryDataTableParamModel {
    public String sEcho;
    public String sSearch;
    public int iDisplayLength;
    public int iDisplayStart;
    public int iColumns;
    public int iSortingCols;
    public int iSortColumnIndex;
    public String sSortDirection;
    public String sColumns;

    public JQueryDataTableParamModel() {
    }
}
