/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tsoft.web.model;

public class SelectModel {
    private Object code;
    private Object libelle;

    public SelectModel() {
    }

    public Object getCode() {
        return this.code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Object getLibelle() {
        return this.libelle;
    }

    public void setLibelle(Object libelle) {
        this.libelle = libelle;
    }
}
