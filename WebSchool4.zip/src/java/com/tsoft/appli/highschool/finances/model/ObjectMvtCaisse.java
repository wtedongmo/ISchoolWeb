/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tsoft.appli.highschool.finances.model;

/**
 *
 * @author tchipi
 */
public enum ObjectMvtCaisse {

    ECOLAGE,
    FRAIS_ETUDE_DOSSIER,
    FRAIS_EXAMEN,
    APE,
    AUTRES,
    SALAIRES,
    FACTURES,
    TRANSFERT,
    PRELEVEMENT;

}
