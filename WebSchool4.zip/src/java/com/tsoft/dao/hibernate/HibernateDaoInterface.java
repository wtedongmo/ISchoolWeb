package com.tsoft.dao.hibernate;

import com.tsoft.dao.InterfaceDao;

public interface HibernateDaoInterface<T> extends InterfaceDao<T> {
}
